# GeoAtlas 世界版图探索（Android）

一个深色科技风的 Android 地理探索应用起始项目。

## 当前包含
- Kotlin Android 容器，竖屏显示
- Leaflet 世界地图，OpenStreetMap 标准底图
- OpenTopoMap 地形底图切换
- Nominatim 地名搜索，尝试获取行政区 GeoJSON 边界并红色高亮
- 根据边界几何估算面积
- 国家级人口、GDP、人均 GDP：REST Countries + 世界银行 API
- 维基百科搜索：区域历史与相关人物资料
- 安卓端将当前 WebView 地图画面保存为 PNG 到 Pictures/GeoAtlas
- 简单地区面积对比

## 使用方法
1. 安装 Android Studio（建议近期稳定版）和 Android SDK 35。
2. Android Studio 选择 **Open**，打开本项目目录。
3. 等待 Gradle Sync 完成。
4. 连接开启开发者选项和 USB 调试的 Android 手机，点击 Run；或使用 Build > Build APK(s)。
5. 首次启动需联网。

## 重要说明
- 这是可继续开发的 MVP 项目，不是已经覆盖全球所有县级边界和统计数据的成品数据库。
- Nominatim 的搜索与边界数据覆盖不均；复杂或超大 GeoJSON 可能加载较慢。请遵守其服务使用政策，正式商用建议部署自有地理编码服务。
- 世界银行 GDP/人口指标为国家级年度数据，不能冒充省、市、县级数据。
- 维基百科搜索结果是线索与条目入口，不等同于经过编辑审核的历史研究。
- 地形底图为在线瓦片服务，地图数据版权和归属以各服务商政策为准。
- 当前图片导出保存的是屏幕地图视图截图，不是透明背景的纯行政区轮廓图；后续可增加专业版图导出。
- 地图、地理编码、统计及百科接口均需要网络，服务可用性受第三方政策与限流影响。

## 下一阶段建议
1. 引入稳定的全球行政区划 GeoJSON 数据集和本地缓存。
2. 增加多区域选择、颜色图例与可配置对比指标。
3. 接入可靠的省市县统计数据源，并标注统计年份和口径。
4. 将地形、历史事件、人物资料拆成独立数据模块。
5. 加入离线地图、导出纯轮廓版图、收藏夹和分享。


## 只有手机时如何在线构建 APK（无需 Android Studio）
本项目包含 GitHub Actions 工作流 `.github/workflows/android.yml`，可在 GitHub 云端编译 Debug APK。

1. 在手机浏览器打开 GitHub 并登录/注册账号。
2. 创建一个新的 **Public** 或 **Private** repository（仓库）。
3. 将本 ZIP 解压后的项目文件上传到仓库根目录。注意要上传 `.github/workflows/android.yml`；手机文件管理器若隐藏点开头文件，请确认该文件也已上传。
4. 上传完成后，进入仓库的 **Actions** 标签页。
5. 选择 **Build GeoAtlas APK** 工作流，点击 **Run workflow**（若 push 到 main 分支也会自动运行）。
6. 等待任务变成绿色成功，打开该次运行记录，在 **Artifacts** 区域下载 `GeoAtlas-debug-apk`。
7. 解压下载的 artifact，即可得到 `app-debug.apk`。在 Android 手机上打开 APK 安装；系统可能会要求允许浏览器/文件管理器安装此来源的应用。

提示：
- GitHub Actions 的免费额度和私有仓库限制以 GitHub 当前政策为准。
- Debug APK 适合个人测试，不是上架商店用的正式签名版本。
- 若构建失败，打开 Actions 日志，把红色报错部分发来即可继续排查。
